﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace telephone_psycho_IN
{
    public partial class psycho2cs : Form
    {
        public psycho2cs()
        {
            InitializeComponent();
        }

        private void price_RaschetBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.price_RaschetBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.telephone_psychoDataSet);

        }

        private void psycho2cs_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "telephone_psychoDataSet.Price_Raschet". При необходимости она может быть перемещена или удалена.
            this.price_RaschetTableAdapter.Fill(this.telephone_psychoDataSet.Price_Raschet);

        }
    }
}
